from ansible.plugins.callback import CallbackBase

class CallbackModule(CallbackBase):
    CALLBACK_VERSION = 2.0
    CALLBACK_TYPE = 'stdout'
    CALLBACK_NAME = 'simple_logger'

    def v2_runner_on_ok(self, result):
        task_name = result.task_name or result._task.get_name()
        host = result._host.get_name()
        msg = result._result.get('msg', '')
        print(f"[{host}]  TASK OK: {task_name} → {msg}")
