import os
from ansible.plugins.lookup import LookupBase

class LookupModule(LookupBase):
    def run(self, terms, variables=None, **kwargs):
        values = []
        for term in terms:
            values.append(os.getenv(term, "NOT_SET"))
        return values
