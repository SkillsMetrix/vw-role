from ansible.module_utils.basic import AnsibleModule
import subprocess

def run_module():
    module = AnsibleModule(
        argument_spec=dict(
            name=dict(type='str', required=True)
        ),
        supports_check_mode=True
    )

    service_name = module.params['name']

    try:
        result = subprocess.run(
            ["systemctl", "is-active", service_name],
            capture_output=True,
            text=True
        )

        status = result.stdout.strip()
    except Exception as e:
        module.fail_json(msg=str(e))

    module.exit_json(
        changed=False,
        service=service_name,
        status=status
    )

def main():
    run_module()

if __name__ == '__main__':
    main()
