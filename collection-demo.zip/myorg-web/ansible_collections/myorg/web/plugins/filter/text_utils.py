class FilterModule(object):
    def filters(self):
        return {
            'normalize_name': self.normalize_name
        }

    def normalize_name(self, value):
        if not isinstance(value, str):
            return value
        return value.lower().replace(" ", "_")
